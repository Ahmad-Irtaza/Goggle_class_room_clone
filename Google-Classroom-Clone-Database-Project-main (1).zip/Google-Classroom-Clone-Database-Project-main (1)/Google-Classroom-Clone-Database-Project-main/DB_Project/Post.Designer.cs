﻿namespace DB_Project
{
    partial class Post
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel4 = new Panel();
            panel8 = new Panel();
            panel16 = new Panel();
            textBox1 = new TextBox();
            panel19 = new Panel();
            panel17 = new Panel();
            panel13 = new Panel();
            panel15 = new Panel();
            dateTimePicker1 = new DateTimePicker();
            panel14 = new Panel();
            label2 = new Label();
            panel12 = new Panel();
            panel9 = new Panel();
            comboBox1 = new ComboBox();
            panel11 = new Panel();
            panel10 = new Panel();
            title = new TextBox();
            panel20 = new Panel();
            panel7 = new Panel();
            panel6 = new Panel();
            panel5 = new Panel();
            panel2 = new Panel();
            button1 = new Button();
            panel18 = new Panel();
            label1 = new Label();
            panel3 = new Panel();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            panel8.SuspendLayout();
            panel16.SuspendLayout();
            panel13.SuspendLayout();
            panel15.SuspendLayout();
            panel14.SuspendLayout();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(764, 444);
            panel1.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel8);
            panel4.Controls.Add(panel7);
            panel4.Controls.Add(panel6);
            panel4.Controls.Add(panel5);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(0, 60);
            panel4.Name = "panel4";
            panel4.Size = new Size(764, 384);
            panel4.TabIndex = 1;
            // 
            // panel8
            // 
            panel8.Controls.Add(panel16);
            panel8.Controls.Add(panel13);
            panel8.Controls.Add(panel12);
            panel8.Controls.Add(panel9);
            panel8.Dock = DockStyle.Fill;
            panel8.Location = new Point(26, 20);
            panel8.Name = "panel8";
            panel8.Size = new Size(451, 364);
            panel8.TabIndex = 3;
            // 
            // panel16
            // 
            panel16.BackColor = Color.WhiteSmoke;
            panel16.Controls.Add(textBox1);
            panel16.Controls.Add(panel19);
            panel16.Controls.Add(panel17);
            panel16.Dock = DockStyle.Fill;
            panel16.Location = new Point(0, 102);
            panel16.Name = "panel16";
            panel16.Size = new Size(451, 262);
            panel16.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.Dock = DockStyle.Fill;
            textBox1.Location = new Point(0, 0);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "   Write here";
            textBox1.Size = new Size(436, 236);
            textBox1.TabIndex = 4;
            // 
            // panel19
            // 
            panel19.Dock = DockStyle.Right;
            panel19.Location = new Point(436, 0);
            panel19.Name = "panel19";
            panel19.Size = new Size(15, 236);
            panel19.TabIndex = 3;
            // 
            // panel17
            // 
            panel17.Dock = DockStyle.Bottom;
            panel17.Location = new Point(0, 236);
            panel17.Name = "panel17";
            panel17.Size = new Size(451, 26);
            panel17.TabIndex = 1;
            // 
            // panel13
            // 
            panel13.Controls.Add(panel15);
            panel13.Controls.Add(panel14);
            panel13.Dock = DockStyle.Top;
            panel13.Location = new Point(0, 59);
            panel13.Name = "panel13";
            panel13.Size = new Size(451, 43);
            panel13.TabIndex = 3;
            // 
            // panel15
            // 
            panel15.BackColor = Color.WhiteSmoke;
            panel15.Controls.Add(dateTimePicker1);
            panel15.Dock = DockStyle.Fill;
            panel15.Location = new Point(139, 0);
            panel15.Name = "panel15";
            panel15.Size = new Size(312, 43);
            panel15.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Dock = DockStyle.Left;
            dateTimePicker1.Location = new Point(0, 0);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 0;
            // 
            // panel14
            // 
            panel14.BackColor = Color.WhiteSmoke;
            panel14.Controls.Add(label2);
            panel14.Dock = DockStyle.Left;
            panel14.Location = new Point(0, 0);
            panel14.Name = "panel14";
            panel14.Size = new Size(139, 43);
            panel14.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Right;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(47, 0);
            label2.Name = "label2";
            label2.Padding = new Padding(0, 1, 10, 0);
            label2.Size = new Size(92, 24);
            label2.TabIndex = 0;
            label2.Text = "Due Date";
            // 
            // panel12
            // 
            panel12.BackColor = Color.WhiteSmoke;
            panel12.Dock = DockStyle.Top;
            panel12.Location = new Point(0, 41);
            panel12.Name = "panel12";
            panel12.Size = new Size(451, 18);
            panel12.TabIndex = 2;
            // 
            // panel9
            // 
            panel9.BackColor = Color.WhiteSmoke;
            panel9.Controls.Add(comboBox1);
            panel9.Controls.Add(panel11);
            panel9.Controls.Add(panel10);
            panel9.Dock = DockStyle.Top;
            panel9.Location = new Point(0, 0);
            panel9.Name = "panel9";
            panel9.Size = new Size(451, 41);
            panel9.TabIndex = 1;
            // 
            // comboBox1
            // 
            comboBox1.Dock = DockStyle.Bottom;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Announcement", "Assignment", "Material" });
            comboBox1.Location = new Point(139, 13);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(270, 28);
            comboBox1.TabIndex = 2;
            comboBox1.Text = "  Select type of Post";
            // 
            // panel11
            // 
            panel11.Dock = DockStyle.Right;
            panel11.Location = new Point(409, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(42, 41);
            panel11.TabIndex = 1;
            // 
            // panel10
            // 
            panel10.Controls.Add(title);
            panel10.Controls.Add(panel20);
            panel10.Dock = DockStyle.Left;
            panel10.Location = new Point(0, 0);
            panel10.Name = "panel10";
            panel10.Size = new Size(139, 41);
            panel10.TabIndex = 0;
            // 
            // title
            // 
            title.Dock = DockStyle.Bottom;
            title.Location = new Point(0, 14);
            title.Name = "title";
            title.PlaceholderText = "  Title";
            title.Size = new Size(129, 27);
            title.TabIndex = 1;
            // 
            // panel20
            // 
            panel20.Dock = DockStyle.Right;
            panel20.Location = new Point(129, 0);
            panel20.Name = "panel20";
            panel20.Size = new Size(10, 41);
            panel20.TabIndex = 0;
            // 
            // panel7
            // 
            panel7.BackColor = Color.WhiteSmoke;
            panel7.Dock = DockStyle.Right;
            panel7.Location = new Point(477, 20);
            panel7.Name = "panel7";
            panel7.Size = new Size(287, 364);
            panel7.TabIndex = 2;
            // 
            // panel6
            // 
            panel6.BackColor = Color.WhiteSmoke;
            panel6.Dock = DockStyle.Left;
            panel6.Location = new Point(0, 20);
            panel6.Name = "panel6";
            panel6.Size = new Size(26, 364);
            panel6.TabIndex = 1;
            // 
            // panel5
            // 
            panel5.BackColor = Color.WhiteSmoke;
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(764, 20);
            panel5.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.WhiteSmoke;
            panel2.Controls.Add(button1);
            panel2.Controls.Add(panel18);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(panel3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(764, 60);
            panel2.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.LightSeaGreen;
            button1.Dock = DockStyle.Right;
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(646, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 60);
            button1.TabIndex = 3;
            button1.Text = "Post";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel18
            // 
            panel18.Dock = DockStyle.Right;
            panel18.Location = new Point(740, 0);
            panel18.Name = "panel18";
            panel18.Size = new Size(24, 60);
            panel18.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Left;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(52, 0);
            label1.Name = "label1";
            label1.Padding = new Padding(10, 15, 0, 0);
            label1.Size = new Size(282, 46);
            label1.TabIndex = 1;
            label1.Text = "Post Something to Class";
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(52, 60);
            panel3.TabIndex = 0;
            // 
            // Post
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Post";
            Size = new Size(764, 444);
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            panel13.ResumeLayout(false);
            panel15.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            panel9.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel4;
        private Panel panel6;
        private Panel panel5;
        private Panel panel2;
        private Label label1;
        private Panel panel3;
        private Panel panel7;
        private Panel panel8;
        private Panel panel13;
        private DateTimePicker dateTimePicker1;
        private Panel panel12;
        private Panel panel9;
        private ComboBox comboBox1;
        private Panel panel11;
        private Panel panel10;
        private Panel panel16;
        private Panel panel17;
        private Panel panel15;
        private Panel panel14;
        private Label label2;
        private Button button1;
        private Panel panel18;
        private TextBox textBox1;
        private Panel panel19;
        private TextBox title;
        private Panel panel20;
    }
}
