﻿namespace DB_Project
{
    partial class HomePage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            panel1 = new Panel();
            panel4 = new Panel();
            panel7 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            button1 = new Button();
            panel5 = new Panel();
            panel16 = new Panel();
            panel18 = new Panel();
            panel22 = new Panel();
            panel14 = new Panel();
            panel13 = new Panel();
            panel19 = new Panel();
            panel21 = new Panel();
            label6 = new Label();
            label5 = new Label();
            panel20 = new Panel();
            panel15 = new Panel();
            panel8 = new Panel();
            panel11 = new Panel();
            label4 = new Label();
            panel10 = new Panel();
            panel9 = new Panel();
            panel6 = new Panel();
            panel12 = new Panel();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            panel7.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            panel16.SuspendLayout();
            panel18.SuspendLayout();
            panel13.SuspendLayout();
            panel19.SuspendLayout();
            panel21.SuspendLayout();
            panel8.SuspendLayout();
            panel11.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1280, 109);
            panel1.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel7);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(153, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(979, 105);
            panel4.TabIndex = 3;
            // 
            // panel7
            // 
            panel7.Controls.Add(label2);
            panel7.Controls.Add(label1);
            panel7.Dock = DockStyle.Fill;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(979, 105);
            panel7.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Cursor = Cursors.Hand;
            label2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(541, 51);
            label2.Name = "label2";
            label2.Size = new Size(118, 31);
            label2.TabIndex = 1;
            label2.Text = "Classwork";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(414, 51);
            label1.Name = "label1";
            label1.Size = new Size(105, 31);
            label1.TabIndex = 0;
            label1.Text = "  Stream ";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Click += label1_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(153, 105);
            panel3.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(10, 11);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(118, 81);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Dock = DockStyle.Right;
            panel2.Location = new Point(1132, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(144, 105);
            panel2.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(23, 25);
            button1.Name = "button1";
            button1.Size = new Size(101, 57);
            button1.TabIndex = 0;
            button1.Text = "Log Out";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel5
            // 
            panel5.BackColor = SystemColors.ButtonHighlight;
            panel5.Controls.Add(panel16);
            panel5.Controls.Add(panel8);
            panel5.Controls.Add(panel6);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(0, 109);
            panel5.Name = "panel5";
            panel5.Size = new Size(1280, 728);
            panel5.TabIndex = 1;
            // 
            // panel16
            // 
            panel16.Controls.Add(panel18);
            panel16.Controls.Add(panel14);
            panel16.Controls.Add(panel13);
            panel16.Controls.Add(panel15);
            panel16.Dock = DockStyle.Fill;
            panel16.Location = new Point(0, 224);
            panel16.Name = "panel16";
            panel16.Size = new Size(1280, 504);
            panel16.TabIndex = 5;
            // 
            // panel18
            // 
            panel18.AutoScroll = true;
            panel18.Controls.Add(panel22);
            panel18.Dock = DockStyle.Fill;
            panel18.Location = new Point(319, 20);
            panel18.Margin = new Padding(3, 4, 3, 4);
            panel18.Name = "panel18";
            panel18.Size = new Size(764, 484);
            panel18.TabIndex = 7;
            // 
            // panel22
            // 
            panel22.Dock = DockStyle.Bottom;
            panel22.Location = new Point(0, 444);
            panel22.Name = "panel22";
            panel22.Size = new Size(764, 40);
            panel22.TabIndex = 0;
            // 
            // panel14
            // 
            panel14.Dock = DockStyle.Right;
            panel14.Location = new Point(1083, 20);
            panel14.Margin = new Padding(3, 4, 3, 4);
            panel14.Name = "panel14";
            panel14.Size = new Size(197, 484);
            panel14.TabIndex = 5;
            // 
            // panel13
            // 
            panel13.Controls.Add(panel19);
            panel13.Dock = DockStyle.Left;
            panel13.Location = new Point(0, 20);
            panel13.Margin = new Padding(3, 4, 3, 4);
            panel13.Name = "panel13";
            panel13.Size = new Size(319, 484);
            panel13.TabIndex = 4;
            // 
            // panel19
            // 
            panel19.BackColor = Color.Transparent;
            panel19.Controls.Add(panel21);
            panel19.Controls.Add(panel20);
            panel19.Dock = DockStyle.Top;
            panel19.Location = new Point(0, 0);
            panel19.Name = "panel19";
            panel19.Size = new Size(319, 205);
            panel19.TabIndex = 0;
            // 
            // panel21
            // 
            panel21.BackColor = Color.WhiteSmoke;
            panel21.Controls.Add(label6);
            panel21.Controls.Add(label5);
            panel21.Dock = DockStyle.Right;
            panel21.Location = new Point(155, 0);
            panel21.Name = "panel21";
            panel21.Size = new Size(154, 205);
            panel21.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.LimeGreen;
            label6.Location = new Point(17, 60);
            label6.Name = "label6";
            label6.Size = new Size(66, 28);
            label6.TabIndex = 1;
            label6.Text = "label6";
            label6.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(17, 24);
            label5.Name = "label5";
            label5.Size = new Size(113, 19);
            label5.TabIndex = 0;
            label5.Text = "Work Nearby";
            // 
            // panel20
            // 
            panel20.BackColor = Color.Transparent;
            panel20.Dock = DockStyle.Right;
            panel20.Location = new Point(309, 0);
            panel20.Name = "panel20";
            panel20.Size = new Size(10, 205);
            panel20.TabIndex = 0;
            // 
            // panel15
            // 
            panel15.Dock = DockStyle.Top;
            panel15.Location = new Point(0, 0);
            panel15.Margin = new Padding(3, 4, 3, 4);
            panel15.Name = "panel15";
            panel15.Size = new Size(1280, 20);
            panel15.TabIndex = 3;
            // 
            // panel8
            // 
            panel8.Controls.Add(panel11);
            panel8.Controls.Add(panel10);
            panel8.Controls.Add(panel9);
            panel8.Dock = DockStyle.Top;
            panel8.Location = new Point(0, 12);
            panel8.Name = "panel8";
            panel8.Size = new Size(1280, 212);
            panel8.TabIndex = 1;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Teal;
            panel11.Controls.Add(label4);
            panel11.Dock = DockStyle.Fill;
            panel11.Location = new Point(155, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(942, 212);
            panel11.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Bottom;
            label4.Font = new Font("Arial", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(0, 141);
            label4.Name = "label4";
            label4.Padding = new Padding(21, 0, 0, 20);
            label4.Size = new Size(519, 71);
            label4.TabIndex = 0;
            label4.Text = "Database Systems Lab";
            // 
            // panel10
            // 
            panel10.Dock = DockStyle.Right;
            panel10.Location = new Point(1097, 0);
            panel10.Name = "panel10";
            panel10.Size = new Size(183, 212);
            panel10.TabIndex = 1;
            // 
            // panel9
            // 
            panel9.Dock = DockStyle.Left;
            panel9.Location = new Point(0, 0);
            panel9.Name = "panel9";
            panel9.Size = new Size(155, 212);
            panel9.TabIndex = 0;
            // 
            // panel6
            // 
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(1280, 12);
            panel6.TabIndex = 0;
            // 
            // panel12
            // 
            panel12.BackColor = SystemColors.ButtonFace;
            panel12.Dock = DockStyle.Bottom;
            panel12.Location = new Point(0, 806);
            panel12.Name = "panel12";
            panel12.Size = new Size(1280, 31);
            panel12.TabIndex = 2;
            // 
            // HomePage
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1280, 837);
            Controls.Add(panel12);
            Controls.Add(panel5);
            Controls.Add(panel1);
            Name = "HomePage";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel16.ResumeLayout(false);
            panel18.ResumeLayout(false);
            panel13.ResumeLayout(false);
            panel19.ResumeLayout(false);
            panel21.ResumeLayout(false);
            panel21.PerformLayout();
            panel8.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button button1;
        private Label label2;
        private Label label1;
        private Panel panel3;
        private PictureBox pictureBox1;
        private Panel panel5;
        private Panel panel7;
        private Panel panel4;
        private Panel panel8;
        private Panel panel11;
        private Label label4;
        private Panel panel10;
        private Panel panel9;
        private Panel panel6;
        private Panel panel12;
        private Panel panel16;
        private Panel panel18;
        private Panel panel14;
        private Panel panel13;
        private Panel panel15;
        private Panel panel19;
        private Panel panel21;
        private Label label5;
        private Panel panel20;
        private Panel panel22;
        private Label label6;
    }
}